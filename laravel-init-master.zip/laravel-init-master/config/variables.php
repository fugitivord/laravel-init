<?php
  // Variables
  return [
    "creatorName" => "EL RINCON DE ISMA",
    "creatorUrl" => "https://me.elrincondeisma.com/",
    "templateName" => "ERDI",
    "templateSuffix" => "Bootstrap Admin Template",
    "templateVersion" => "1.0.0",
    "templateFree" => true,
    "templateDescription" => "Start your development with a Dashboard for Bootstrap 5",
    "templateKeyword" => "dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5",
    "licenseUrl" => "",
    "livePreview" => "",
    "productPage" => "",
    "support" => "",
    "moreThemes" => "",
    "documentation" => "",
    "generator" => "",
    "changelog" => "",
    "repository" => "",
    "gitAuthor" => "",
    "gitRepo" => "",
    "facebookUrl" => "",
    "twitterUrl" => "",
    "githubUrl" => "",
    "dribbbleUrl" => "",
    "instagramUrl" => ""
  ];
