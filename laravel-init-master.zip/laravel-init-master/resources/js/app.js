import * as alpine from 'alpinejs/dist/cdn';


export { alpine };
