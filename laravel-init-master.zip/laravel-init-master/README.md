# El Rincon de Isma
## Template for Laravel install